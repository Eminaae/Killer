package ba.bitcamp.lectures.classes.structure;

public class Ocjena {
	public String predmet;
	public String ocjena;

}
