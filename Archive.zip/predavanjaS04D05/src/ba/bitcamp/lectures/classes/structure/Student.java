package ba.bitcamp.lectures.classes.structure;

public class Student {
	public String ime, prezime, jmbg;
	public ocjena[] ocjene;
	public 

}
