package ba.bitcamp;

import java.awt.Color;

public class Car {
	String name;
	Color color;
	int year;
	int horsePower;
	
	Car (String name, int year, int horsePower, Color color) {
		this.name = name;
		this.year = year;
		this.horsePower = horsePower;
		this.color = color;
	}
	

}
