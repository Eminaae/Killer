package bo.bitcamp.music;

public class Performer {
	String name;
	boolean isGroup;
	int since;
	String genere;

}
